import pandas as pd
from datetime import datetime
from airflow.models import DAG
from airflow.operators.python import PythonOperator
from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import Variable
from airflow.operators.bash import BashOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from datetime import datetime, timedelta
from Helens_grupp.simons_databasgrej import insert_data_to_dbs
from Helens_grupp.etl_meteo import request_new_weather_data, transform, rename
# from Helens_grupp.too_easy_simon import plot_weather

args = {
    'owner': 'Helen ALbandak',
    'start_date': datetime(2023, 1, 1)
}

dag = DAG(
    dag_id='my_dag',
    default_args=args,
    schedule='@daily' # make this workflow happen every day
)

with dag:

    request_new_weather_data = PythonOperator(
        task_id='request_new_weather_data',
        python_callable= request_new_weather_data
    )
    transform = PythonOperator(
        task_id='transform',
        python_callable= transform
        # provide_context=True
    )
    rename= PythonOperator(
        task_id='rename',
        python_callable= rename
    )

    insert_data_to_dbs = PythonOperator(
         task_id='insert_data_to_db',
         python_callable= insert_data_to_dbs
     )

    # plot_weather = PythonOperator(
    #      task_id='make_graph',
    #      python_callable= plot_weather,
    #      do_xcom_push=True
    #      # provide_context=True
    #  )


  #  transform.set_upstream(request_new_weather_data)
   # rename.set_upstream(transform)
   # insert_data_to_dbs.set_upstream(rename)
    # plot_weather.set_upstream(insert_data_to_dbs)
    request_new_weather_data >>  transform >> rename >> insert_data_to_dbs